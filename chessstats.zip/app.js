'use strict';

// ===== CONFIGURATION =====
const CONFIG = {
    playerColors: {
        Carlos: '#7c3aed',
        Carey: '#00d4ff',
        Jorge: '#10b981'
    },
    animationDuration: 2000,
    chartColors: {
        white: '#f8f9fa',
        black: '#475569',
        draw: '#7c3aed'
    }
};

// ===== STATISTICS DATA =====
const STATS = {"totalGames":296,"players":["Carlos","Carey","Jorge"],"playerStats":{"Carlos":{"totalGames":255,"wins":136,"losses":111,"winRate":53.3},"Carey":{"totalGames":122,"wins":60,"losses":60,"winRate":49.2},"Jorge":{"totalGames":215,"wins":91,"losses":116,"winRate":42.3}},"headToHead":{"Carlos_vs_Carey":{"total":81,"player1":"Carlos","player2":"Carey","player1Wins":44,"player2Wins":36,"draws":1},"Carlos_vs_Jorge":{"total":174,"player1":"Carlos","player2":"Jorge","player1Wins":92,"player2Wins":75,"draws":7},"Carey_vs_Jorge":{"total":41,"player1":"Carey","player2":"Jorge","player1Wins":24,"player2Wins":16,"draws":1}},"colorStats":{"whiteWins":141,"blackWins":146,"draws":9},"victoryMethods":{"Checkmate":238,"Resigned":45,"Stalemate":8,"Time":3,"Resignation":1},"brutality":{"totalBrutalGames":47,"byPlayer":{"Carlos":{"inflicted":44,"suffered":26},"Carey":{"inflicted":45,"suffered":60},"Jorge":{"inflicted":41,"suffered":44}},"topGames":[{"date":"2025-05-12","winner":"Jorge","loser":"Carey","rating":5,"note":"Grampa was gonna force the draw via the 50 move rule; Carey tipped his king in frustration with the peanut gallery (Carlos).Carey fladgulated himself to loss."},{"date":"2025-01-11","winner":"Carlos","loser":"Carey","rating":4,"note":""},{"date":"2025-03-17","winner":"Carey","loser":"Jorge","rating":4,"note":""},{"date":"2025-03-23","winner":"Carlos","loser":"Carey","rating":4,"note":"Scholar's Mate"},{"date":"2025-03-29","winner":"Carey","loser":"Carlos","rating":4,"note":""},{"date":"2025-06-08","winner":"Carlos","loser":"Carey","rating":4,"note":""},{"date":"2025-06-17","winner":"Jorge","loser":"Carey","rating":4,"note":"Annoyance"}]},"timeStats":{"peakHour":21,"peakHourGames":62,"byPeriod":{"Evening":192,"Afternoon":75,"Night":28,"Morning":1}},"sessions":{"total":50,"avgGames":5.9,"epicSessions":[{"date":"2025-09-27","games":25,"wins":{"Carlos":11,"Carey":4,"Jorge":9}},{"date":"2025-12-30","games":22,"wins":{"Carlos":12,"Carey":1,"Jorge":9}},{"date":"2025-12-24","games":19,"wins":{"Carlos":8,"Carey":3,"Jorge":8}},{"date":"2025-05-22","games":13,"wins":{"Carlos":5,"Jorge":7}},{"date":"2025-04-06","games":12,"wins":{"Carlos":9,"Carey":1,"Jorge":1}},{"date":"2025-11-05","games":12,"wins":{"Carlos":7,"Jorge":4}},{"date":"2025-06-17","games":11,"wins":{"Carlos":2,"Carey":4,"Jorge":5}},{"date":"2025-07-13","games":11,"wins":{"Carlos":3,"Jorge":8}},{"date":"2025-09-06","games":11,"wins":{"Carlos":4,"Carey":3,"Jorge":4}},{"date":"2025-06-13","games":10,"wins":{"Carlos":4,"Jorge":6}},{"date":"2025-08-11","games":10,"wins":{"Carlos":4,"Carey":4,"Jorge":2}}]},"streaks":{"Carlos":7,"Carey":6,"Jorge":8},"monthly":{"January":{"games":9,"wins":{"Carlos":7,"Carey":1,"Jorge":1}},"February":{"games":20,"wins":{"Carlos":10,"Carey":6,"Jorge":4}},"March":{"games":18,"wins":{"Carlos":7,"Carey":8,"Jorge":2}},"April":{"games":12,"wins":{"Carlos":9,"Carey":1,"Jorge":1}},"May":{"games":34,"wins":{"Carlos":8,"Carey":8,"Jorge":16}},"June":{"games":26,"wins":{"Carlos":8,"Carey":7,"Jorge":11}},"July":{"games":14,"wins":{"Carlos":4,"Carey":1,"Jorge":8}},"August":{"games":22,"wins":{"Carlos":10,"Carey":8,"Jorge":3}},"September":{"games":43,"wins":{"Carlos":20,"Carey":7,"Jorge":14}},"October":{"games":19,"wins":{"Carlos":7,"Carey":4,"Jorge":8}},"November":{"games":33,"wins":{"Carlos":24,"Carey":2,"Jorge":6}},"December":{"games":46,"wins":{"Carlos":22,"Carey":7,"Jorge":17}}},"quarterly":{"Q1":{"games":47,"wins":{"Carlos":24,"Carey":15,"Jorge":7}},"Q2":{"games":72,"wins":{"Carlos":25,"Carey":16,"Jorge":28}},"Q3":{"games":79,"wins":{"Carlos":34,"Carey":16,"Jorge":25}},"Q4":{"games":98,"wins":{"Carlos":53,"Carey":13,"Jorge":31}}}};

// ===== UTILITY FUNCTIONS =====
const Utils = {
    createElement(tag, className = '', content = '') {
        const el = document.createElement(tag);
        if (className) el.className = className;
        if (content) el.innerHTML = content;
        return el;
    },
    
    animateCounter(element, target, decimals = 0) {
        if (!element) return;
        let start = 0;
        const increment = target / (CONFIG.animationDuration / 16);
        const timer = setInterval(() => {
            start += increment;
            if (start >= target) {
                element.textContent = decimals > 0 ? target.toFixed(decimals) : Math.round(target);
                clearInterval(timer);
            } else {
                element.textContent = decimals > 0 ? start.toFixed(decimals) : Math.floor(start);
            }
        }, 16);
    },
    
    formatDate(dateStr) {
        const date = new Date(dateStr);
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return `${months[date.getMonth()]} ${date.getDate()}`;
    },
    
    getWinner(matchup) {
        const {player1, player2, player1Wins, player2Wins} = matchup;
        return player1Wins >= player2Wins ? player1 : player2;
    }
};

// ===== SVG CHART COMPONENTS =====
const Charts = {
    createDoughnut(player1Wins, player2Wins, draws, color1, color2) {
        const total = player1Wins + player2Wins + draws;
        if (total === 0) return '';
        
        const radius = 58;
        const innerRadius = 42;
        const centerX = 70;
        const centerY = 70;
        
        const data = [
            {value: player1Wins, color: color1},
            {value: draws, color: '#475569'},
            {value: player2Wins, color: color2}
        ].filter(d => d.value > 0);
        
        let currentAngle = -90;
        let paths = '';
        
        data.forEach((item, index) => {
            const sliceAngle = (item.value / total) * 360;
            const endAngle = currentAngle + sliceAngle;
            
            const startRad = (currentAngle * Math.PI) / 180;
            const endRad = (endAngle * Math.PI) / 180;
            
            const x1 = centerX + radius * Math.cos(startRad);
            const y1 = centerY + radius * Math.sin(startRad);
            const x2 = centerX + radius * Math.cos(endRad);
            const y2 = centerY + radius * Math.sin(endRad);
            const x3 = centerX + innerRadius * Math.cos(endRad);
            const y3 = centerY + innerRadius * Math.sin(endRad);
            const x4 = centerX + innerRadius * Math.cos(startRad);
            const y4 = centerY + innerRadius * Math.sin(startRad);
            
            const largeArc = sliceAngle > 180 ? 1 : 0;
            
            paths += `
                <path d="M ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} L ${x3} ${y3} A ${innerRadius} ${innerRadius} 0 ${largeArc} 0 ${x4} ${y4} Z"
                      fill="url(#grad${index})" 
                      stroke="rgba(255,255,255,0.1)" 
                      stroke-width="1"
                      style="filter: drop-shadow(0 0 6px ${item.color}40); opacity: 0; animation: fadeIn 0.6s ease-out ${0.1 + index * 0.1}s forwards; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);"
                      onmouseenter="this.style.transform='scale(1.05)'; this.style.transformOrigin='${centerX}px ${centerY}px'; this.style.filter='drop-shadow(0 0 12px ${item.color}80) brightness(1.15)';"
                      onmouseleave="this.style.transform='scale(1)'; this.style.filter='drop-shadow(0 0 6px ${item.color}40)';" />
            `;
            currentAngle = endAngle;
        });
        
        const gradients = data.map((item, i) => `
            <linearGradient id="grad${i}" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="${item.color}" stop-opacity="1"/>
                <stop offset="100%" stop-color="${item.color}" stop-opacity="0.7"/>
            </linearGradient>
        `).join('');
        
        return `
            <svg width="140" height="140" style="position: relative;">
                <defs>${gradients}</defs>
                ${paths}
            </svg>
        `;
    }
};

// ===== COMPONENTS =====
const Components = {
    playerLegend() {
        return STATS.players.map(player => `
            <div class="player-legend__item">
                <div class="player-legend__dot" style="background: ${CONFIG.playerColors[player]}; box-shadow: 0 0 12px ${CONFIG.playerColors[player]};"></div>
                <span class="player-legend__name" style="color: ${CONFIG.playerColors[player]};">${player}</span>
            </div>
        `).join('');
    },
    
    overview() {
        return `
            <div class="card stats-grid--full animate-in">
                <h2 class="card__title">Tournament Overview</h2>
                <div class="text-center mb-lg">
                    <div class="stat-number stat-number--large" data-count="${STATS.totalGames}">0</div>
                    <div class="stat-label">Total Games Played</div>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--spacing-md);">
                    <div class="text-center">
                        <div class="stat-number stat-number--medium" data-count="${STATS.sessions.total}">0</div>
                        <div class="stat-label">Sessions</div>
                    </div>
                    <div class="text-center">
                        <div class="stat-number stat-number--medium" data-count="${STATS.brutality.totalBrutalGames}">0</div>
                        <div class="stat-label">Brutal Games</div>
                    </div>
                    <div class="text-center">
                        <div class="stat-number stat-number--medium" data-count="${Math.max(...Object.values(STATS.streaks))}">0</div>
                        <div class="stat-label">Longest Streak</div>
                    </div>
                </div>
            </div>
        `;
    },
    
    playerCard(player, delay = 0) {
        const stats = STATS.playerStats[player];
        const color = CONFIG.playerColors[player];
        const gradient = `linear-gradient(90deg, ${color} 0%, ${color}cc 100%)`;
        
        return `
            <div class="card animate-in" data-animate-delay="${delay}">
                <h2 class="card__title" style="border-color: ${color};">${player}</h2>
                <div class="text-center mb-md">
                    <div class="stat-number" style="color: ${color};" data-count="${stats.wins}">0</div>
                    <div class="stat-label">${stats.totalGames} Games • ${stats.winRate}% Win Rate</div>
                </div>
                <div style="background: rgba(255,255,255,0.05); border-radius: 8px; padding: 0.75rem; margin-top: 1rem;">
                    <div style="font-family: 'JetBrains Mono', monospace; text-align: center; color: var(--color-text-secondary); font-size: 1.1rem;">
                        ${stats.wins}W - ${stats.losses}L
                    </div>
                    <div style="background: rgba(255,255,255,0.1); height: 8px; border-radius: 4px; margin-top: 0.5rem; overflow: hidden;">
                        <div style="background: ${gradient}; height: 100%; width: ${stats.winRate}%; border-radius: 4px; transition: width 1s cubic-bezier(0.4, 0, 0.2, 1);"></div>
                    </div>
                </div>
            </div>
        `;
    },
    
    headToHead() {
        const matchups = Object.values(STATS.headToHead);
        
        const cards = matchups.map((matchup, index) => {
            const {player1, player2, player1Wins, player2Wins, draws, total} = matchup;
            const winner = Utils.getWinner(matchup);
            const leftPlayer = winner === player1 ? player1 : player2;
            const rightPlayer = winner === player1 ? player2 : player1;
            const leftWins = winner === player1 ? player1Wins : player2Wins;
            const rightWins = winner === player1 ? player2Wins : player1Wins;
            const leftColor = CONFIG.playerColors[leftPlayer];
            const rightColor = CONFIG.playerColors[rightPlayer];
            
            return `
                <div class="card animate-in" data-animate-delay="${index + 1}">
                    <div style="display: flex; flex-direction: column; align-items: center; gap: 0.75rem;">
                        <div style="position: relative; width: 140px; height: 140px;">
                            ${Charts.createDoughnut(leftWins, rightWins, draws, leftColor, rightColor)}
                            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; pointer-events: none;">
                                <div style="font-family: 'Space Grotesk', sans-serif; font-size: 1.8rem; font-weight: 700; color: var(--color-text-primary);">${total}</div>
                                <div style="font-family: 'Inter', sans-serif; font-size: 0.7rem; color: rgba(248, 249, 250, 0.6); text-transform: uppercase; letter-spacing: 1px;">games</div>
                            </div>
                        </div>
                        <div style="text-align: center; width: 100%;">
                            <div style="display: flex; justify-content: space-around; align-items: center; margin-bottom: 0.5rem;">
                                <div style="text-align: center;">
                                    <div style="font-family: 'Space Grotesk', sans-serif; font-size: 1.2rem; font-weight: 700; color: ${leftColor}; margin-bottom: 0.25rem;">${leftPlayer}</div>
                                    <div style="font-family: 'JetBrains Mono', monospace; font-size: 1.1rem; font-weight: 600; color: ${leftColor};">${((leftWins/total)*100).toFixed(1)}%</div>
                                </div>
                                <div style="font-family: 'Space Grotesk', sans-serif; font-size: 1.5rem; font-weight: 700; color: rgba(248, 249, 250, 0.5);">vs</div>
                                <div style="text-align: center;">
                                    <div style="font-family: 'Space Grotesk', sans-serif; font-size: 1.2rem; font-weight: 700; color: ${rightColor}; margin-bottom: 0.25rem;">${rightPlayer}</div>
                                    <div style="font-family: 'JetBrains Mono', monospace; font-size: 1.1rem; font-weight: 600; color: ${rightColor};">${((rightWins/total)*100).toFixed(1)}%</div>
                                </div>
                            </div>
                            <div style="font-family: 'Space Grotesk', sans-serif; font-size: 1.5rem; font-weight: 700;">
                                <span style="color: ${leftColor}">${leftWins}</span> - <span style="color: #64748b">${draws}</span> - <span style="color: ${rightColor}">${rightWins}</span>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
        
        return `
            <div class="card stats-grid--full animate-in" data-animate-delay="4">
                <h2 class="card__title">Head-to-Head Records</h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: var(--spacing-md);">
                    ${cards}
                </div>
            </div>
        `;
    },
    
    brutality() {
        const topGames = STATS.brutality.topGames.slice(0, 5).map((game, index) => {
            const color = CONFIG.playerColors[game.winner];
            const stars = '⭐'.repeat(game.rating);
            const noteHtml = game.note ? `<div style="font-style: italic; margin-top: 0.5rem; color: rgba(248, 249, 250, 0.7); font-size: 0.9rem;">"${game.note}"</div>` : '';
            
            return `
                <div style="background: rgba(0, 0, 0, 0.3); border-left: 4px solid ${color}; padding: 1.25rem; margin-bottom: 0.75rem; border-radius: 8px; transition: all 0.3s ease;"
                     onmouseenter="this.style.background='${color}26'; this.style.transform='translateX(5px)';"
                     onmouseleave="this.style.background='rgba(0, 0, 0, 0.3)'; this.style.transform='translateX(0)';">
                    <div style="display: flex; justify-content: space-between; align-items: start;">
                        <div style="flex: 1;">
                            <div style="font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 1.1rem; color: var(--color-text-primary);">${Utils.formatDate(game.date)}</div>
                            <div style="font-family: 'JetBrains Mono', monospace; color: ${color}; margin-top: 0.5rem; font-size: 0.95rem;">
                                ${game.winner} destroyed ${game.loser}
                            </div>
                            ${noteHtml}
                        </div>
                        <div style="font-size: 1.3rem; margin-left: 1rem;">${stars}</div>
                    </div>
                </div>
            `;
        }).join('');
        
        return `
            <div class="card stats-grid--full animate-in" data-animate-delay="5">
                <h2 class="card__title">Most Savage Moments</h2>
                <div style="margin-bottom: 1.5rem; padding: 1rem; background: rgba(255, 255, 255, 0.03); border-radius: 8px; border-left: 3px solid var(--color-accent-neutral);">
                    <div style="font-family: 'Space Grotesk', sans-serif; font-weight: 600; margin-bottom: 0.5rem;">Top ${STATS.brutality.topGames.length} Brutal Games</div>
                    <div style="font-family: 'Inter', sans-serif; font-size: 0.9rem; color: var(--color-text-secondary);">
                        Games rated by savagery on a 1-5 star scale
                    </div>
                </div>
                ${topGames}
            </div>
        `;
    },
    
    sessions() {
        const sessions = STATS.sessions.epicSessions.map((session, index) => {
            const sortedWins = Object.entries(session.wins).sort((a, b) => b[1] - a[1]);
            const winsHtml = sortedWins.map(([player, wins]) => `
                <span style="color: ${CONFIG.playerColors[player]}; font-weight: 700;">${player}: ${wins}</span>
            `).join(' • ');
            
            return `
                <div style="background: rgba(255, 255, 255, 0.03); border-radius: 12px; padding: 1.25rem; margin-bottom: 0.75rem; border-left: 3px solid var(--color-accent-neutral); transition: all 0.3s ease;"
                     onmouseenter="this.style.background='rgba(156, 163, 175, 0.1)'; this.style.transform='translateX(5px)';"
                     onmouseleave="this.style.background='rgba(255, 255, 255, 0.03)'; this.style.transform='translateX(0)';">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                        <div style="font-family: 'Space Grotesk', sans-serif; font-weight: 700; font-size: 1.1rem;">${Utils.formatDate(session.date)}</div>
                        <div style="font-family: 'JetBrains Mono', monospace; font-size: 1.3rem; font-weight: 700; color: var(--color-accent-neutral);">${session.games} games</div>
                    </div>
                    <div style="font-family: 'JetBrains Mono', monospace; font-size: 0.95rem; color: var(--color-text-secondary);">
                        ${winsHtml}
                    </div>
                </div>
            `;
        }).join('');
        
        return `
            <div class="card stats-grid--full animate-in" data-animate-delay="6">
                <h2 class="card__title">Epic Sessions (10+ Games)</h2>
                ${sessions}
            </div>
        `;
    }
};

// ===== APP CLASS =====
class App {
    constructor() {
        this.appElement = document.getElementById('app');
        this.legendElement = document.getElementById('playerLegend');
        this.init();
    }
    
    init() {
        this.renderLegend();
        this.render();
        this.animateCounters();
    }
    
    renderLegend() {
        this.legendElement.innerHTML = Components.playerLegend();
    }
    
    render() {
        const html = `
            ${Components.overview()}
            ${STATS.players.map((player, i) => Components.playerCard(player, i + 1)).join('')}
            ${Components.headToHead()}
            ${Components.brutality()}
            ${Components.sessions()}
        `;
        
        this.appElement.innerHTML = html;
    }
    
    animateCounters() {
        requestAnimationFrame(() => {
            const counters = document.querySelectorAll('[data-count]');
            counters.forEach(counter => {
                const target = parseFloat(counter.dataset.count);
                const decimals = counter.dataset.count.includes('.') ? 1 : 0;
                Utils.animateCounter(counter, target, decimals);
            });
        });
    }
}

// ===== START APP =====
document.addEventListener('DOMContentLoaded', () => {
    new App();
});
